document.write("<h1>Is my web page accessible?</h1>");
document.write("<p>Not necessarily!</p>");