var
	v1 = 10,
	v2 = 20,
	v3 = 30,
	v4 = 40,
	v5 = 50;

var mean = (v1 + v2 + v3 + v4 + v5) / 5;

alert(mean);