// JavaScript ternary operator

var x;

if (a) {
	x = b;
}
else {
	x = c;
}


// equivalent to:
var x = (a ? b : c);