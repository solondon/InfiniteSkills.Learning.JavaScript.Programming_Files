// prompt for name
var msg = document.getElementById("message");
var name = prompt("What is your name?", "");
var output = "";



// output message
msg.textContent = output;